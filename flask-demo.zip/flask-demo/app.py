from flask import Flask, Response
import database_services.RDBService as d_service
from database_services import *
from flask_cors import CORS
import json

import logging

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger()
logger.setLevel(logging.INFO)

from application_services.db_users_resource import IMDBUsersResource
from application_services.UsersResource.user_service import UserResource


app = Flask(__name__)
CORS(app)

@app.route('/')
def hello_world():
    return '<u>Hello World!</u>'

# added app
@app.route('/Welcome')
def welcome():
    return '<head>Welcome to my page!</head>'

# find users by name
@app.route('/hw1_db/users/userName/<name>')
def get_users_by_name(name):
    res = IMDBUsersResource.get_by_name(name)
    rsp = Response(json.dumps(res), status=200, content_type="application/json")
    return rsp

# update users' email by uid
@app.route('/hw1_db/users/<uid>/<email>')
def update_usersEmail_by_uid(uid, email):
    res = IMDBUsersResource.updateEmail_by_uid(uid, email)
    rsp = Response(json.dumps(res), status=200, content_type="application/json")
    return rsp


# insert tuple to users
@app.route('/hw1_db/users/<userID>/<userName>/<userEmail>/<userPWD>/<address>/<Preference>/<links>')
def insert_into_users(userID,userName,userEmail,userPWD,address,Preference,links):
    res = IMDBUsersResource.insert_into_users(userID,userName,userEmail,userPWD,address,Preference,links)
    rsp = Response(json.dumps(res), status=200, content_type="application/json")
    return rsp


'''
@app.route('/users')
def get_users():
    res = UserResource.get_by_template(None)
    rsp = Response(json.dumps(res, default=str), status=200, content_type="application/json")
    return rsp


@app.route('/<db_schema>/<table_name>/<column_name>/<prefix>')
def get_by_prefix(db_schema, table_name, column_name, prefix):
    res = d_service.get_by_prefix(db_schema, table_name, column_name, prefix)
    rsp = Response(json.dumps(res, default=str), status=200, content_type="application/json")
    return rsp
'''

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000)  # running on localhost
