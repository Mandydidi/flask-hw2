#from application_services.BaseApplicationResource import BaseApplicationResource
#from BaseApplicationResource import *
import database_services.RDBService as d_service
from abc import ABC



class BaseApplicationResource(ABC):

    def __init__(self):
        pass
    '''
    @abstractmethod
    def get_links(self, resource_data):
        pass
    '''

class IMDBUsersResource(BaseApplicationResource):

    def __init__(self):
        super().__init__()

    @classmethod
    def get_by_name(cls, Name):
        res = d_service.get_by_prefix("hw1_db", "users",
                                      "userName", Name)
        if len(res) == 0:
            return 'Find 0 result.'
        return res

    @classmethod
    def updateEmail_by_uid(cls, uid, email):
        try:
            res = d_service.updateEmail_by_uid("hw1_db", "users",
                                      "userID", "userEmail", uid, email)
            return 'Update successfully.'
        except:
            return 'Failed.'

    @classmethod
    def insert_into_users(cls, uid, name, email, pwd, add, pre, links):

        res = d_service.insert_into_Users("hw1_db", "users", uid, name, email, pwd, add, pre, links)
        if len(res) == 0:
            return 'Find 0 result.'
        return res



