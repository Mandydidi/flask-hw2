import pymysql
import json
import logging

from middleware import context as context

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def _get_db_connection():

    db_connect_info = context.get_db_info()

    logger.info("RDBService._get_db_connection:")
    logger.info("\t HOST = " + db_connect_info['host'])

    db_info = context.get_db_info()
    db_connection = pymysql.connect(
       **db_info
    )
    return db_connection


def get_by_prefix(db_schema, table_name, column_name, value_prefix):

    conn = _get_db_connection()
    cur = conn.cursor()

    sql = "select * from " + db_schema + "." + table_name + " where " + \
        column_name + " like " + "'" + value_prefix + "%';"
    print("SQL Statement = " + cur.mogrify(sql, None))

    res = cur.execute(sql)
    res = cur.fetchall()

    conn.close()

    return res

def updateEmail_by_uid(db_schema, table_name, col1, col2, uid, email):

    conn = _get_db_connection()
    cur = conn.cursor()

    sql = "update " + db_schema + "." + table_name + " set " + \
        col2 + "=" + "'" + email + "'" + " where " + col1 + "=" + "'" + uid + "';"
    print("SQL Statement = " + cur.mogrify(sql, None))

    res = cur.execute(sql)
    res = cur.fetchall()

    conn.close()

    return res

def insert_into_Users(db_schema, table_name, uid, name, email, pwd, add, pre, links):

    conn = _get_db_connection()
    cur = conn.cursor()

    sql = "insert into " + db_schema + "." + table_name + " (userID, userName, userEmail, userPWD, address, Preference, Links)" + " values (" + \
        "'" + uid + "', " + "'" + name + "', " + "'" + email + "', " + \
          "" + "'" + pwd + "', " + "'" + add + "', " + "'" + pre + "', " + \
          "'" + links + "');"
    print("SQL Statement = " + cur.mogrify(sql, None))

    res = cur.execute(sql)
    res = cur.fetchall()

    sql = "select * from hw1_db.users;"
    res = cur.execute(sql)
    res = cur.fetchall()

    conn.close()

    return res


def _get_where_clause_args(template):

    terms = []
    args = []
    clause = None

    if template is None or template == {}:
        clause = ""
        args = None
    else:
        for k,v in template.items():
            terms.append(k + "=%s")
            args.append(v)

        clause = " where " +  " AND ".join(terms)


    return clause, args


def find_by_template(db_schema, table_name, template, field_list):

    wc,args = _get_where_clause_args(template)

    conn = _get_db_connection()
    cur = conn.cursor()

    sql = "select * from " + db_schema + "." + table_name + " " + wc
    res = cur.execute(sql, args=args)
    res = cur.fetchall()

    conn.close()

    return res

